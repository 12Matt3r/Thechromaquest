# 🚀 ChromaShift Browser Extension - Installation Guide

## Quick Installation

### For Chrome/Edge Users:
1. **Download the extension folder** `chromashift-extension` to your computer
2. **Open your browser** and navigate to:
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
3. **Enable Developer Mode** (toggle in top-right corner)
4. **Click "Load unpacked"** and select the `chromashift-extension` folder
5. **Done!** The ChromaShift icon should appear in your browser toolbar

### For Firefox Users:
1. **Go to** `about:debugging#/runtime/this-firefox`
2. **Click "Load Temporary Add-on"**
3. **Select any file** from the `chromashift-extension` folder
4. **Note**: Firefox will require reloading the extension each time

## 🎮 How to Play

### Method 1: Extension Popup (Recommended)
1. **Click the ChromaShift icon** in your toolbar
2. **Choose "Launch Reality Hacker"** to play inline
3. **Or "Open in New Tab"** for full-screen experience

### Method 2: New Tab Override
1. **Right-click the ChromaShift icon** in toolbar
2. **Select "Options"** (Chrome) or "Manage Extension" (Edge)
3. **Enable "New Tab Override"** in settings
4. **Open a new tab** - ChromaShift will launch automatically!

### Method 3: Direct Access
1. **Navigate to** `chrome-extension://` in your address bar
2. **Or use** the API: `window.ChromaShiftAPI.generateProceduralQuest()`

## 🎯 Game Features Available

✅ **AI Companion (Cortana)** - Chat with evolving AI personality
✅ **Procedural Quests** - Infinite unique content generation  
✅ **3D Environments** - WebGL-powered immersive spaces
✅ **Multiplayer** - Collaborate with other players
✅ **Spatial Audio** - 3D positioned sound effects
✅ **Reality Hacking** - Modify simulation parameters
✅ **Achievement System** - Track your progress
✅ **Cross-device Sync** - Continue where you left off

## 🔧 API Access (For Developers)

Open browser console and try:

```javascript
// Generate a new quest
window.ChromaShiftAPI.generateProceduralQuest({
  difficulty: 5,
  questType: 'narrative_discovery'
});

// Chat with AI
window.ChromaShiftAPI.chatWithAI("What should I explore next?");

// Get current status
window.ChromaShiftAPI.getGameState();
```

## 🆘 Troubleshooting

**Extension not loading?**
- Ensure Developer Mode is enabled
- Check that all files are in the folder
- Look for errors in browser console (F12)

**Game won't start?**
- Try the New Tab method instead of inline
- Check that pop-ups aren't blocked
- Refresh the page and try again

**Performance issues?**
- Lower graphics quality in game settings
- Close other browser tabs
- Update your graphics drivers

## 📱 Mobile Support

The extension works on:
- ✅ Desktop Chrome/Edge/Firefox
- ✅ Tablet Chrome/Edge (Android/iPadOS)
- ✅ Mobile Chrome/Edge (basic functionality)

## 🔐 Privacy & Permissions

Required permissions explained:
- **storage**: Save your game progress
- **activeTab**: Inject game into current page
- **tabs**: Manage game in new tabs
- **host_permissions**: Access game files

**No data is sent anywhere** - everything runs locally in your browser!

## 🎨 Customization

Access settings via:
- **Extension popup** → Settings button
- **Browser console** → `window.ChromaShiftAPI`
- **Game menu** → Options → Preferences

## 💾 Backup & Restore

Your progress is saved automatically to browser storage.
To backup:
1. Open extension popup
2. Go to Settings
3. Click "Export Progress"

To restore:
1. Install extension
2. Go to Settings  
3. Click "Import Progress"

---

## 🎉 Ready to Begin!

**ChromaShift** is now ready to transform your browser into a cyberpunk reality hacking adventure!

**Questions?** Check the main README.md or visit the GitHub repository.

**Enjoy hacking reality!** ⚡