// Background Service Worker for ChromaShift Extension
// Handles extension startup, storage, and cross-tab communication

chrome.runtime.onInstalled.addListener(() => {
  console.log('ChromaShift Extension installed');
  
  // Initialize default settings
  chrome.storage.sync.get(['gameSettings', 'playerProgress'], (result) => {
    if (!result.gameSettings) {
      chrome.storage.sync.set({
        gameSettings: {
          soundEnabled: true,
          musicVolume: 0.7,
          sfxVolume: 0.8,
          graphicsQuality: 'high',
          accessibilityEnabled: true,
          notificationsEnabled: true
        }
      });
    }
    
    if (!result.playerProgress) {
      chrome.storage.sync.set({
        playerProgress: {
          level: 1,
          experience: 0,
          skills: {},
          achievements: [],
          questProgress: {},
          multiplayerStats: {}
        }
      });
    }
  });
  
  // Set badge text to show extension is ready
  chrome.action.setBadgeText({ text: '✓' });
  chrome.action.setBadgeBackgroundColor({ color: '#00E5D1' });
});

chrome.runtime.onStartup.addListener(() => {
  console.log('ChromaShift Extension started');
  chrome.action.setBadgeText({ text: '✓' });
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPlayerProgress') {
    chrome.storage.sync.get(['playerProgress'], (result) => {
      sendResponse(result.playerProgress);
    });
    return true; // Keep message channel open
  }
  
  if (request.action === 'savePlayerProgress') {
    chrome.storage.sync.set({ playerProgress: request.data });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'getGameSettings') {
    chrome.storage.sync.get(['gameSettings'], (result) => {
      sendResponse(result.gameSettings);
    });
    return true;
  }
  
  if (request.action === 'updateGameSettings') {
    chrome.storage.sync.set({ gameSettings: request.data });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'openGameInTab') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('game/chromashift-complete.html')
    });
    sendResponse({ success: true });
    return true;
  }
});

// Handle extension action clicks
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('game/chromashift-complete.html')
  });
});