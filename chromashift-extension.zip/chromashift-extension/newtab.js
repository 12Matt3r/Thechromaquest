// ChromaShift New Tab JavaScript
// Handles new tab page interactions and game launching

class ChromaShiftNewTab {
  constructor() {
    this.launchBtn = document.getElementById('launchGameBtn');
    this.popupBtn = document.getElementById('openPopupBtn');
    this.loading = document.getElementById('loading');
    this.statusElements = {
      system: document.getElementById('systemStatus'),
      reality: document.getElementById('realityStatus'),
      anomalies: document.getElementById('anomalyCount'),
      level: document.getElementById('playerLevel')
    };
    
    this.init();
  }
  
  async init() {
    this.setupEventListeners();
    await this.loadPlayerData();
    this.startStatusUpdates();
    this.animateElements();
  }
  
  setupEventListeners() {
    this.launchBtn.addEventListener('click', () => this.launchGame());
    this.popupBtn.addEventListener('click', () => this.openExtensionPopup());
  }
  
  async launchGame() {
    this.showLoading(true);
    
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'openGameInTab'
      });
      
      if (response && response.success) {
        this.updateStatus('system', 'Game Launched');
        setTimeout(() => this.showLoading(false), 2000);
      } else {
        throw new Error('Failed to launch game');
      }
    } catch (error) {
      console.error('Failed to launch game:', error);
      this.updateStatus('system', 'Launch Failed');
      this.showLoading(false);
      alert('Failed to launch game. Please try again.');
    }
  }
  
  openExtensionPopup() {
    // Get the current tab and click the extension icon
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        // Open extension popup by clicking action
        chrome.action.openPopup();
      }
    });
  }
  
  showLoading(show) {
    if (show) {
      this.loading.classList.add('show');
      this.launchBtn.disabled = true;
      this.popupBtn.disabled = true;
      this.launchBtn.textContent = 'Launching...';
    } else {
      this.loading.classList.remove('show');
      this.launchBtn.disabled = false;
      this.popupBtn.disabled = false;
      this.launchBtn.textContent = 'Launch Reality Hacker';
    }
  }
  
  async loadPlayerData() {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'getPlayerProgress'
      });
      
      if (response) {
        this.updatePlayerDisplay(response);
      }
    } catch (error) {
      console.error('Failed to load player data:', error);
    }
  }
  
  updatePlayerDisplay(playerData) {
    if (playerData.level) {
      this.updateStatus('level', playerData.level);
    }
  }
  
  updateStatus(type, value) {
    if (this.statusElements[type]) {
      this.statusElements[type].textContent = value;
      
      // Add animation effect
      this.statusElements[type].style.transform = 'scale(1.1)';
      setTimeout(() => {
        this.statusElements[type].style.transform = 'scale(1)';
      }, 200);
    }
  }
  
  startStatusUpdates() {
    // Update reality stability with realistic fluctuation
    setInterval(() => {
      const baseReality = 98.7;
      const variation = Math.sin(Date.now() / 15000) * 1.5 + Math.random() * 0.5;
      const reality = (baseReality + variation).toFixed(1);
      this.updateStatus('reality', reality + '%');
    }, 4000);
    
    // Update anomaly count
    setInterval(() => {
      const anomalyBase = 12;
      const anomalyVariation = Math.floor(Math.random() * 8) - 4;
      const count = Math.max(1, anomalyBase + anomalyVariation);
      this.updateStatus('anomalies', count);
    }, 6000);
    
    // Cycle through system statuses
    const statuses = ['Online', 'Synchronized', 'Secure', 'Optimized', 'Connected'];
    let statusIndex = 0;
    setInterval(() => {
      this.updateStatus('system', statuses[statusIndex]);
      statusIndex = (statusIndex + 1) % statuses.length;
    }, 8000);
  }
  
  animateElements() {
    // Add entrance animations
    const cards = document.querySelectorAll('.status-card');
    cards.forEach((card, index) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      
      setTimeout(() => {
        card.style.transition = 'all 0.6s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, 200 + (index * 100));
    });
    
    // Animate feature items
    const features = document.querySelectorAll('.feature-item');
    features.forEach((feature, index) => {
      feature.style.opacity = '0';
      feature.style.transform = 'translateX(-20px)';
      
      setTimeout(() => {
        feature.style.transition = 'all 0.5s ease';
        feature.style.opacity = '1';
        feature.style.transform = 'translateX(0)';
      }, 1000 + (index * 100));
    });
  }
}

// Initialize new tab page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ChromaShiftNewTab();
});

// Handle keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // Alt + G to launch game
  if (e.altKey && e.key === 'g') {
    e.preventDefault();
    document.getElementById('launchGameBtn').click();
  }
  
  // Alt + P to open popup
  if (e.altKey && e.key === 'p') {
    e.preventDefault();
    document.getElementById('openPopupBtn').click();
  }
});