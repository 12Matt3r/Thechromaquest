// ChromaShift Extension Popup JavaScript
// Handles popup interactions and game launching

class ChromaShiftPopup {
  constructor() {
    this.launchBtn = document.getElementById('launchBtn');
    this.newTabBtn = document.getElementById('newTabBtn');
    this.loading = document.getElementById('loading');
    this.systemStatus = document.getElementById('systemStatus');
    this.realityStatus = document.getElementById('realityStatus');
    this.anomalyCount = document.getElementById('anomalyCount');
    this.playerLevel = document.getElementById('playerLevel');
    
    this.init();
  }
  
  async init() {
    this.setupEventListeners();
    await this.loadPlayerData();
    this.startStatusUpdates();
  }
  
  setupEventListeners() {
    this.launchBtn.addEventListener('click', () => this.launchGame());
    this.newTabBtn.addEventListener('click', () => this.launchInNewTab());
  }
  
  async launchGame() {
    this.showLoading(true);
    
    try {
      // Check if we can inject content script
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tab) {
        await this.injectGameIntoTab(tab);
      } else {
        await this.launchInNewTab();
      }
    } catch (error) {
      console.error('Failed to launch game:', error);
      // Fallback to new tab
      await this.launchInNewTab();
    } finally {
      this.showLoading(false);
    }
  }
  
  async launchInNewTab() {
    this.showLoading(true);
    
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'openGameInTab'
      });
      
      if (response && response.success) {
        // Close popup after successful launch
        setTimeout(() => window.close(), 500);
      }
    } catch (error) {
      console.error('Failed to open in new tab:', error);
      this.showLoading(false);
      alert('Failed to launch game. Please try again.');
    }
  }
  
  async injectGameIntoTab(tab) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tab.id, {
        action: 'injectGame'
      }, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else if (response && response.success) {
          resolve(response);
        } else {
          reject(new Error('Failed to inject game'));
        }
      });
    });
  }
  
  showLoading(show) {
    if (show) {
      this.loading.classList.add('show');
      this.launchBtn.disabled = true;
      this.newTabBtn.disabled = true;
      this.launchBtn.textContent = 'Launching...';
    } else {
      this.loading.classList.remove('show');
      this.launchBtn.disabled = false;
      this.newTabBtn.disabled = false;
      this.launchBtn.textContent = 'Launch Reality Hacker';
    }
  }
  
  async loadPlayerData() {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'getPlayerProgress'
      });
      
      if (response) {
        this.updatePlayerDisplay(response);
      }
    } catch (error) {
      console.error('Failed to load player data:', error);
    }
  }
  
  updatePlayerDisplay(playerData) {
    // Update player level
    if (playerData.level) {
      this.playerLevel.textContent = playerData.level;
    }
    
    // Generate realistic-looking stats
    this.updateDynamicStats();
  }
  
  updateDynamicStats() {
    // Generate realistic-looking dynamic stats
    const baseReality = 98.7;
    const variation = Math.sin(Date.now() / 10000) * 2;
    this.realityStatus.textContent = (baseReality + variation).toFixed(1) + '%';
    
    // Vary anomaly count
    const anomalyBase = 12;
    const anomalyVariation = Math.floor(Math.random() * 5) - 2;
    this.anomalyCount.textContent = Math.max(1, anomalyBase + anomalyVariation);
  }
  
  startStatusUpdates() {
    // Update stats every 3 seconds for dynamic feel
    setInterval(() => {
      this.updateDynamicStats();
    }, 3000);
    
    // Update system status occasionally
    setInterval(() => {
      const statuses = ['Online', 'Synchronized', 'Secure', 'Optimized'];
      this.systemStatus.textContent = statuses[Math.floor(Math.random() * statuses.length)];
    }, 15000);
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ChromaShiftPopup();
});

// Handle popup opening
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'popupOpened') {
    // Popup was opened, perform any initialization
    console.log('ChromaShift popup opened');
  }
});