// ChromaShift Extension API Documentation
// Complete guide to procedural generation and narrative systems

// ===== CORE GAME ACCESS =====
const ChromaShiftAPI = {
  // Access the main game instance
  get game() {
    return window.chromaShiftComplete;
  },

  // ===== PROCEDURAL QUEST GENERATION =====
  
  /**
   * Generate a new procedural quest with full customization
   * @param {Object} options - Quest generation options
   * @param {string} options.seed - Deterministic seed for reproduction
   * @param {number} options.difficulty - Difficulty level (1-10)
   * @param {string} options.questType - Quest type: 'anomaly_hunt', 'dimensional_exploration', 'reality_calibration', 'cognitive_test', 'narrative_discovery', 'multiplayer_cooperation', 'combat_trial', 'reality_stabilization'
   * @param {boolean} options.autoAccept - Auto-add to active quests
   * @returns {Object} Generated quest object
   */
  generateProceduralQuest(options = {}) {
    const game = this.game;
    if (!game) throw new Error('ChromaShift game not loaded');
    
    const quest = game.generateProceduralQuest(
      options.seed || Date.now(),
      options.difficulty || 5,
      options.questType
    );
    
    if (options.autoAccept && game.acceptQuest) {
      game.acceptQuest(quest);
    }
    
    return quest;
  },

  /**
   * Generate multiple quests at once
   * @param {number} count - Number of quests to generate
   * @param {Object} baseOptions - Base options for all quests
   * @returns {Array} Array of generated quests
   */
  generateQuestBatch(count, baseOptions = {}) {
    const quests = [];
    for (let i = 0; i < count; i++) {
      quests.push(this.generateProceduralQuest({
        ...baseOptions,
        seed: Date.now() + i
      }));
    }
    return quests;
  },

  /**
   * Get quest generation statistics
   * @returns {Object} Quest generation stats
   */
  getQuestGenerationStats() {
    return {
      totalGenerated: this.game?.proceduralQuestStats?.totalGenerated || 0,
      recentActivity: this.game?.proceduralQuestStats?.recentActivity || 0,
      currentDifficulty: this.game?.proceduralQuestStats?.currentDifficulty || 5,
      systemStatus: this.game?.proceduralQuestStats?.active ? 'Active' : 'Inactive'
    };
  },

  // ===== AI COMPANION SYSTEM =====
  
  /**
   * Get AI companion (Cortana) instance
   * @returns {Object} AI companion object with personality, mood, and memories
   */
  getAICompanion() {
    return this.game?.aiCompanion;
  },

  /**
   * Send message to AI companion and get response
   * @param {string} message - Player message
   * @param {Object} options - Response options
   * @param {boolean} options.showInUI - Display response in game UI
   * @param {boolean} options.affectPersonality - Allow personality changes
   * @returns {string} AI response
   */
  chatWithAI(message, options = {}) {
    const game = this.game;
    if (!game?.aiCompanion) throw new Error('AI companion not available');
    
    const response = game.generateCompanionResponse(message);
    
    if (options.affectPersonality !== false) {
      game.analyzePersonalityChange(message, response);
    }
    
    if (options.showInUI !== false) {
      game.updateAIMessage(response);
    }
    
    return response;
  },

  /**
   * Get AI personality analysis
   * @returns {Object} Current personality traits and mood
   */
  getAIPersonality() {
    const companion = this.getAICompanion();
    return {
      personality: companion?.personality || {},
      currentMood: companion?.currentMood || 'neutral',
      trustLevel: companion?.trustLevel || 0,
      memories: companion?.memories?.length || 0,
      conversations: companion?.conversations?.length || 0
    };
  },

  /**
   * Update AI personality directly
   * @param {Object} traits - Personality traits to modify
   */
  modifyAIPersonality(traits) {
    const companion = this.getAICompanion();
    if (!companion?.personality) return;
    
    Object.keys(traits).forEach(trait => {
      if (companion.personality[trait] !== undefined) {
        companion.personality[trait] = Math.max(0, Math.min(100, 
          companion.personality[trait] + traits[trait]));
      }
    });
  },

  // ===== NARRATIVE GENERATION =====
  
  /**
   * Generate narrative content for quest
   * @param {Object} quest - Quest object
   * @param {string} context - Narrative context
   * @returns {string} Generated narrative text
   */
  generateQuestNarrative(quest, context = 'exploration') {
    const game = this.game;
    if (!game) throw new Error('ChromaShift game not loaded');
    
    // Use AI companion to generate narrative based on personality
    const companion = game.aiCompanion;
    let narrative = '';
    
    switch (companion?.currentMood) {
      case 'curious':
        narrative = `Interesting developments in ${context}. I sense new possibilities emerging... `;
        break;
      case 'helpful':
        narrative = `This ${quest.title} presents a unique opportunity for growth. Let me guide you... `;
        break;
      case 'protective':
        narrative = `Proceed with caution. I will watch over you during ${quest.title}. `;
        break;
      default:
        narrative = `Initiating ${quest.title}. Parameters analyzed. `;
    }
    
    // Add procedural elements
    narrative += `The objective: ${quest.objectives[0]}. Location: ${quest.location}. `;
    narrative += `Expected difficulty: ${quest.difficulty}/10. Recommended approach: ${this.getDifficultyStrategy(quest.difficulty)}.`;
    
    return narrative;
  },

  /**
   * Generate contextual responses based on game state
   * @param {string} situation - Current situation
   * @returns {string} Contextual response
   */
  generateContextualResponse(situation) {
    const game = this.game;
    const companion = game?.aiCompanion;
    
    if (!companion) return 'AI companion unavailable.';
    
    const responses = {
      'quest_started': companion.personality.empathy > 50 ? 
        'Exciting! Let\'s explore this together.' :
        'Quest initiated. Beginning analysis.',
      'reality_distortion': 'Reality parameters shifting. Adjusting calculations...',
      'multiplayer_join': companion.personality.curiosity > 60 ?
        'New perspectives incoming. This will be fascinating.' :
        'Additional player detected. Collaboration protocols activated.',
      'achievement_unlocked': companion.personality.empathy > 70 ?
        'Well done! Your progress is remarkable.' :
        'Achievement recorded. Performance metrics updated.'
    };
    
    return responses[situation] || 'Processing current state...';
  },

  // ===== 3D ENVIRONMENT SYSTEM =====
  
  /**
   * Get 3D scene instance
   * @returns {Object} Three.js scene and camera
   */
  get3DScene() {
    return this.game?.scene3D;
  },

  /**
   * Create custom 3D object in environment
   * @param {string} type - Object type
   * @param {Object} position - Position coordinates
   * @param {Object} properties - Object properties
   * @returns {Object} Created 3D object
   */
  create3DObject(type, position = { x: 0, y: 0, z: 0 }, properties = {}) {
    const scene = this.get3DScene();
    if (!scene?.scene) throw new Error('3D scene not available');
    
    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const material = new THREE.MeshBasicMaterial({ 
      color: properties.color || 0x00E5D1,
      transparent: true,
      opacity: properties.opacity || 1.0
    });
    
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(position.x, position.y, position.z);
    
    scene.scene.add(mesh);
    return mesh;
  },

  /**
   * Update 3D object properties
   * @param {Object} object - 3D object to update
   * @param {Object} properties - New properties
   */
  update3DObject(object, properties) {
    if (properties.position && object.position) {
      object.position.set(
        properties.position.x || 0,
        properties.position.y || 0,
        properties.position.z || 0
      );
    }
    
    if (properties.rotation && object.rotation) {
      object.rotation.set(
        properties.rotation.x || 0,
        properties.rotation.y || 0,
        properties.rotation.z || 0
      );
    }
    
    if (properties.scale && object.scale) {
      object.scale.set(
        properties.scale.x || 1,
        properties.scale.y || 1,
        properties.scale.z || 1
      );
    }
  },

  // ===== MULTIPLAYER SYSTEM =====
  
  /**
   * Get multiplayer system instance
   * @returns {Object} Multiplayer system
   */
  getMultiplayerSystem() {
    return this.game?.multiplayerSystem;
  },

  /**
   * Send message to all multiplayer players
   * @param {string} message - Message to broadcast
   * @param {Object} options - Message options
   */
  broadcastMessage(message, options = {}) {
    const multiplayer = this.getMultiplayerSystem();
    if (!multiplayer?.connectedPlayers) {
      throw new Error('Multiplayer system not available');
    }
    
    const messageData = {
      type: options.type || 'chat',
      content: message,
      sender: 'system',
      timestamp: Date.now(),
      ...options
    };
    
    multiplayer.broadcast(messageData);
  },

  /**
   * Get list of connected players
   * @returns {Array} Array of connected player objects
   */
  getConnectedPlayers() {
    const multiplayer = this.getMultiplayerSystem();
    return multiplayer?.connectedPlayers || [];
  },

  // ===== AUDIO SYSTEM =====
  
  /**
   * Get audio system instance
   * @returns {Object} Audio system
   */
  getAudioSystem() {
    return this.game?.audioSystem;
  },

  /**
   * Play spatial audio at position
   * @param {string} audioFile - Audio file path
   * @param {Object} position - 3D position
   * @param {Object} options - Audio options
   */
  playSpatialAudio(audioFile, position, options = {}) {
    const audio = this.getAudioSystem();
    if (!audio?.audioContext) {
      throw new Error('Audio system not available');
    }
    
    const source = audio.audioContext.createBufferSource();
    // Add spatial positioning logic here
    console.log(`Playing ${audioFile} at position:`, position);
  },

  // ===== REALITY HACKING SYSTEM =====
  
  /**
   * Get reality hacking system
   * @returns {Object} Reality hacking interface
   */
  getRealityHackingSystem() {
    return this.game?.realityHackingSystem;
  },

  /**
   * Execute reality code
   * @param {string} code - Reality manipulation code
   * @returns {Object} Execution result
   */
  executeRealityCode(code) {
    const reality = this.getRealityHackingSystem();
    if (!reality?.executeCode) {
      throw new Error('Reality hacking system not available');
    }
    
    return reality.executeCode(code);
  },

  /**
   * Create reality anchor
   * @param {string} name - Anchor name
   * @param {Object} properties - Anchor properties
   * @returns {Object} Created anchor
   */
  createRealityAnchor(name, properties = {}) {
    const reality = this.getRealityHackingSystem();
    if (!reality?.createAnchor) {
      throw new Error('Reality hacking system not available');
    }
    
    return reality.createAnchor(name, properties);
  },

  // ===== UTILITY FUNCTIONS =====
  
  getDifficultyStrategy(difficulty) {
    if (difficulty <= 3) return 'exploratory approach';
    if (difficulty <= 6) return 'strategic planning';
    if (difficulty <= 8) return 'careful execution';
    return 'extreme preparation required';
  },

  /**
   * Get complete game state
   * @returns {Object} Current game state
   */
  getGameState() {
    return {
      playerData: this.game?.playerData || {},
      questSystem: {
        activeQuests: this.game?.questSystem?.activeQuests || [],
        completedQuests: this.game?.questSystem?.completedQuests || [],
        totalQuests: this.game?.questSystem?.questCount || 0
      },
      aiCompanion: this.getAIPersonality(),
      multiplayer: {
        connected: this.game?.multiplayerSystem?.isConnected || false,
        players: this.getConnectedPlayers().length
      },
      realityHacking: {
        parameters: this.game?.realityHackingSystem?.currentParameters || {},
        anchors: this.game?.realityHackingSystem?.anchors?.length || 0
      },
      audioSystem: {
        enabled: this.game?.audioSystem?.enabled || false,
        volume: this.game?.audioSystem?.masterVolume || 0.7
      }
    };
  },

  /**
   * Reset entire game state
   */
  resetGameState() {
    if (this.game?.resetGame) {
      this.game.resetGame();
    }
  },

  /**
   * Save current game state to extension storage
   */
  saveGameState() {
    if (this.game?.saveGameData) {
      chrome.runtime.sendMessage({
        action: 'savePlayerProgress',
        data: this.getGameState()
      });
    }
  },

  /**
   * Load game state from extension storage
   */
  loadGameState() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: 'getPlayerProgress'
      }, (response) => {
        if (response && this.game?.loadGameData) {
          this.game.loadGameData(response);
        }
        resolve(response);
      });
    });
  }
};

// ===== GLOBAL ACCESS =====
window.ChromaShiftAPI = ChromaShiftAPI;

console.log('ChromaShift API loaded. Access via window.ChromaShiftAPI');