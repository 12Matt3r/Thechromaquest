# ChromaShift: Reality Hacking Game - Browser Extension

## 🎮 Overview

ChromaShift is an immersive reality hacking game that transforms your browser into an interactive cyberpunk adventure. Experience AI companions, procedural quest generation, 3D environments, multiplayer collaboration, and advanced reality manipulation - all within your browser.

## ✨ Features

### 🤖 AI Companion System
- **Cortana Dream Guide**: Advanced AI companion with evolving personality
- **Dynamic Conversations**: Context-aware responses based on player interactions
- **Personality Evolution**: AI learns and adapts to your playstyle
- **Emotional Intelligence**: AI responds with empathy, logic, curiosity, and humor

### 🎯 Procedural Quest Generation
- **Infinite Content**: Procedurally generated quests with unique objectives
- **8 Quest Types**: Anomaly hunting, dimensional exploration, reality calibration, cognitive tests, narrative discovery, multiplayer cooperation, combat trials, reality stabilization
- **Dynamic Difficulty**: Adaptive scaling based on player progress
- **Branching Narratives**: Multiple paths and outcomes for each quest

### 🌐 3D Reality Environments
- **Three.js Powered**: Immersive 3D environments with WebGL rendering
- **Interactive Spaces**: Manipulate reality through 3D interfaces
- **Spatial Audio**: Position-based sound for enhanced immersion
- **Reality Nodes**: Interact with dimensional anchors in 3D space

### 👥 Multiplayer Collaboration
- **Real-time Collaboration**: Work together with other players
- **Shared AI Personality**: AI adapts to group dynamics
- **Collaborative Questing**: Team-based objectives and challenges
- **Cross-device Sync**: Seamless experience across all your devices

### 🎵 Advanced Audio System
- **Spatial Positioning**: 3D audio with realistic distance and direction
- **Dynamic Soundscapes**: Audio that adapts to game state
- **Custom Sound Design**: Professional-grade audio effects
- **Accessibility Support**: Audio cues for visually impaired users

### ⚡ Reality Hacking Interface
- **Code-based Reality Manipulation**: Execute reality-changing algorithms
- **Parameter Adjustment**: Fine-tune reality constants
- **Reality Anchors**: Create permanent changes to the simulation
- **Mathematical Precision**: Scientific approach to reality modification

## 🚀 Installation

### Chrome/Edge
1. Download the extension files
2. Open Chrome/Edge and go to `chrome://extensions/` or `edge://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the `chromashift-extension` folder
5. The extension will appear in your toolbar

### Firefox
1. Go to `about:debugging#/runtime/this-firefox`
2. Click "Load Temporary Add-on"
3. Select any file from the `chromashift-extension` folder
4. Firefox will load the extension temporarily

## 🎯 Usage

### Quick Start
1. **Install the extension** following the steps above
2. **Click the extension icon** in your toolbar to launch
3. **Choose your launch method**:
   - **Inline**: Inject game into current webpage
   - **New Tab**: Open in dedicated game tab
   - **Popup Controls**: Quick access via extension popup

### Extension Controls
- **🎮 Launch Game**: Start ChromaShift in full screen
- **🔧 Extension Popup**: Access game controls and settings
- **🌐 New Tab Override**: Set ChromaShift as your new tab page

### Game Controls
- **Mouse**: Interact with UI elements and 3D environments
- **Keyboard**: Navigate menus and input commands
- **Voice**: Communicate with AI companion (when available)

## 🛠️ Development

### API Access
Access the complete ChromaShift API via the browser console:

```javascript
// Generate a new quest
window.ChromaShiftAPI.generateProceduralQuest({
  seed: Date.now(),
  difficulty: 5,
  questType: 'anomaly_hunt',
  autoAccept: true
});

// Chat with AI companion
window.ChromaShiftAPI.chatWithAI("Tell me about current reality state");

// Get game state
window.ChromaShiftAPI.getGameState();

// Access 3D scene
window.ChromaShiftAPI.get3DScene();

// Get multiplayer status
window.ChromaShiftAPI.getConnectedPlayers();
```

### File Structure
```
chromashift-extension/
├── manifest.json          # Extension manifest (v3)
├── background.js          # Service worker
├── content.js             # Content script
├── popup.html             # Extension popup UI
├── popup.js               # Popup functionality
├── newtab.html            # New tab override
├── newtab.js              # New tab functionality
├── game/
│   ├── chromashift-complete.html    # Main game (15,713 lines)
│   └── chromashift-api.js          # Extension API
├── icons/                 # Extension icons (16px, 32px, 48px, 128px)
└── README.md              # This file
```

### Key APIs
- **Procedural Quest Generation**: `generateProceduralQuest()`
- **AI Companion**: `chatWithAI()`, `getAIPersonality()`, `modifyAIPersonality()`
- **3D Environment**: `get3DScene()`, `create3DObject()`, `update3DObject()`
- **Multiplayer**: `broadcastMessage()`, `getConnectedPlayers()`
- **Audio System**: `playSpatialAudio()`
- **Reality Hacking**: `executeRealityCode()`, `createRealityAnchor()`
- **Game State**: `getGameState()`, `saveGameState()`, `loadGameState()`

## 🎨 Customization

### Settings
- **Sound Effects Volume**: 0-100%
- **Music Volume**: 0-100%
- **Graphics Quality**: Low, Medium, High
- **Accessibility**: Screen reader support, high contrast mode
- **Notifications**: Quest alerts, AI messages, multiplayer events

### Personalization
- **AI Personality**: Adjust Cortana's traits (Logic, Empathy, Curiosity, Protection, Humor, Mystery)
- **Quest Preferences**: Set preferred quest types and difficulty ranges
- **Reality Parameters**: Customize simulation constants
- **Audio Settings**: Spatial audio preferences and 3D positioning

## 🔧 Technical Specifications

- **Manifest Version**: 3 (Latest Chrome/Edge standard)
- **Permissions**: storage, activeTab, tabs, host_permissions
- **Browser Support**: Chrome 88+, Edge 88+, Firefox 109+
- **Web APIs**: WebGL, Web Audio API, Local Storage, Chrome Extensions API
- **File Size**: ~560KB (main game) + ~50KB (extension files)
- **Performance**: Optimized for 60fps on modern hardware

## 🛡️ Privacy & Security

- **No Data Collection**: Extension operates locally
- **Secure Storage**: Chrome Extension Storage API
- **Permission Transparency**: Minimal required permissions
- **Offline Capable**: Works without internet connection
- **Open Source**: All code available for review

## 🤝 Contributing

This extension is part of the ChromaShift project:
- **Main Repository**: https://github.com/12Matt3r/Thechromaquest
- **Complete Documentation**: Available in repository
- **Testing Guide**: 200+ test cases included
- **Google Jules Review**: Expert evaluation prompt provided

## 📄 License

ChromaShift Browser Extension - Part of the ChromaShift Project
Developed by MiniMax Agent
See main repository for license details.

## 🆘 Support

### Troubleshooting
1. **Extension not loading**: Ensure Developer mode is enabled
2. **Game not launching**: Check browser console for errors
3. **Performance issues**: Lower graphics quality in settings
4. **Audio problems**: Check browser audio permissions

### Common Issues
- **"Manifest file missing"**: Make sure you're loading the entire extension folder
- **"Content script injection failed"**: Try launching in new tab instead
- **"AI companion not responding"**: Refresh the game page

### Contact
- **GitHub Issues**: Report bugs and feature requests
- **Documentation**: See comprehensive testing guide and progress report
- **Community**: Join discussions in the main repository

---

**🎮 Ready to hack reality? Install ChromaShift and begin your journey! 🎮**