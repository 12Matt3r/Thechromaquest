// Content Script for ChromaShift Extension
// Injects the game into any webpage or opens standalone

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'injectGame') {
    injectChromaShiftGame(sendResponse);
    return true; // Keep message channel open
  }
});

function injectChromaShiftGame(sendResponse) {
  try {
    // Check if game already exists
    if (document.getElementById('chromashift-game-container')) {
      sendResponse({ success: false, message: 'Game already loaded' });
      return;
    }

    // Create game container
    const gameContainer = document.createElement('div');
    gameContainer.id = 'chromashift-game-container';
    gameContainer.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: #000;
      z-index: 999999;
      overflow: hidden;
    `;

    // Create iframe for the game
    const gameIframe = document.createElement('iframe');
    gameIframe.src = chrome.runtime.getURL('game/chromashift-complete.html');
    gameIframe.style.cssText = `
      width: 100%;
      height: 100%;
      border: none;
      background: #000;
    `;

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.innerHTML = '✕';
    closeButton.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1000000;
      width: 40px;
      height: 40px;
      background: rgba(0, 229, 209, 0.9);
      color: #000;
      border: none;
      border-radius: 50%;
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    `;

    closeButton.addEventListener('click', () => {
      gameContainer.remove();
    });

    closeButton.addEventListener('mouseenter', () => {
      closeButton.style.background = '#00E5D1';
      closeButton.style.transform = 'scale(1.1)';
    });

    closeButton.addEventListener('mouseleave', () => {
      closeButton.style.background = 'rgba(0, 229, 209, 0.9)';
      closeButton.style.transform = 'scale(1)';
    });

    // Assemble elements
    gameContainer.appendChild(gameIframe);
    gameContainer.appendChild(closeButton);
    document.body.appendChild(gameContainer);

    sendResponse({ success: true, message: 'Game injected successfully' });
  } catch (error) {
    console.error('Failed to inject ChromaShift game:', error);
    sendResponse({ success: false, message: error.message });
  }
}

// Auto-inject if this is a dedicated game page
if (window.location.href.includes('chromashift-game')) {
  // The game will be loaded by popup.html
  console.log('ChromaShift game page detected');
}